<?php
require_once '../config.php';

// Check if user is logged in and is a worker
if (!is_logged_in() || $_SESSION['user_role'] !== 'worker') {
    json_response(['success' => false, 'message' => 'Unauthorized access']);
}

$user_id = $_SESSION['user_id'];

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if file was uploaded
    if (!isset($_FILES['national_id_photo']) || $_FILES['national_id_photo']['error'] !== UPLOAD_ERR_OK) {
        json_response(['success' => false, 'message' => 'No file uploaded or upload error']);
    }
    
    $file = $_FILES['national_id_photo'];
    
    // Validate file
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    $file_info = pathinfo($file['name']);
    $extension = strtolower($file_info['extension']);
    
    if (!in_array($extension, $allowed_types)) {
        json_response(['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, and GIF files are allowed.']);
    }
    
    if ($file['size'] > 5 * 1024 * 1024) {
        json_response(['success' => false, 'message' => 'File size must be less than 5MB']);
    }
    
    // Generate unique filename
    $filename = 'national_id_' . $user_id . '_' . uniqid() . '.' . $extension;
    $upload_path = '../uploads/' . $filename;
    
    // Create uploads directory if it doesn't exist
    if (!is_dir('../uploads')) {
        mkdir('../uploads', 0777, true);
    }
    
    // Upload file
    if (move_uploaded_file($file['tmp_name'], $upload_path)) {
        // Update database
        $update_sql = "UPDATE workers SET national_id_photo = ? WHERE user_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param('si', $filename, $user_id);
        
        if ($stmt->execute()) {
            json_response([
                'success' => true, 
                'message' => 'National ID photo uploaded successfully',
                'filename' => $filename
            ]);
        } else {
            // Remove uploaded file if database update fails
            unlink($upload_path);
            json_response(['success' => false, 'message' => 'Failed to update database']);
        }
        
        $stmt->close();
    } else {
        json_response(['success' => false, 'message' => 'Failed to upload file']);
    }
}

json_response(['success' => false, 'message' => 'Invalid request method']);
?>
